import pytest
from fixedFunctions import displayItem

def test_isInts(capsys):
    displayItem(1234,2)
    captured_stdout, captured_stderr = capsys.readouterr()
    assert captured_stdout.strip() == "Your item at 2 index is 3"
    
def test_isString(capsys):
    displayItem("1234",2)
    captured_stdout, captured_stderr = capsys.readouterr()
    assert captured_stdout.strip() == "Your item at 2 index is 3"

def test_isList(capsys):
    displayItem([1,2,3,4],2)
    captured_stdout, captured_stderr = capsys.readouterr()
    assert captured_stdout.strip() == "Your item at 2 index is 3"

def test_isSet():
    with pytest.raises(TypeError):
        displayItem({1,2,3,4},2)
        
def test_indexOutOfRange():
    with pytest.raises(IndexError):
        displayItem([1,2,3,4],4)