import math

def openFile(filename): 
    if not isinstance(filename, str):
        raise ValueError("Filename must be a string")
    try:
        with open(filename, "r") as infile:
            print("File opened.")
    except FileNotFoundError:
        print("File not found.")
        raise
    except IsADirectoryError:
        print("Expected a file but got a directory.")
        raise
    except PermissionError:
        print("Insufficient permissions to open the file.")
        raise

def numbers(num1, num2):
    if not isinstance(num1, (int, float)) or not isinstance(num2, (int, float)):
        raise TypeError("Inputs must be numbers.")
    if num2 == 0:
        raise ZeroDivisionError("Cannot divide by zero.")
    return num1 / num2

def dist(x1, y1, x2, y2):
    if not all(isinstance(i, (int, float)) for i in [x1, y1, x2, y2]):
        raise TypeError("Coordinates must be numbers.")
    return math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)

## takes in a string -- reverses it
## then compares the two
def isPalindrome(temp):
    if not isinstance(temp, str):
        raise TypeError("Input must be a string.") # Check if input is a string
    temp = temp.replace(" ", "")  # Remove whitespace
    temp = temp.lower()  # Lowercase
    test = temp[::-1]

    return test == temp

## has input to receive two numbers
## divides the two, then outputs the result
def divide():
    #added input validation
    try:
        num1 = int(input("Enter a number: "))
        num2 = int(input("Enter another number: "))
    except ValueError:
        raise ValueError("Inputs must be numbers.")

    if num2 == 0:
        print("You cannot divide by zero.")
        return None
    
    div = num1 / num2

    print("Your numbers divided is:", div)

## returns the log base 2 of a particular number
def log2(num):
    if not isinstance(num, (int, float)):
        print("Input must be a number.")
        return None
    return math.log2(num)

#############
## tah568 ###
#############

## takes in an age from the user via parameters
## responds based on a couple of criteria
def ageResponse(age):
    if (age < 0):
        raise ValueError
    if(age < 18):
        print("You're a minor!")

    elif(age >= 18 and age < 21):
        print("You're kind of in a weird legal gray area of ages.")

    else:
        print("You're 21 or older!")
        print("You can now drink alcohol AND get married without parental consent in MS. Congrats.")

## takes in a Python list
## attempts to display the item at the index provided
def displayItem(numbers, index):
    if (type(numbers) == int):
        numbers = str(numbers)
    print("Your item at", index, "index is", numbers[index])

## takes in two parameters: start and end
## totals the numbers together so if 1 and 3 are start and end should be:
## 1 + 2 + 3 = 6 to return
def total(start, end):
    if (start > end): raise ValueError
    total = 0

    for i in range(start, end):
        total += i

    return total
