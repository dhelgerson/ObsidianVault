import pytest
from fixedFunctions import log2

def test_positive():
    assert log2(8) == 3
    assert log2(1) == 0
    assert log2(2) == 1

def test_float():
    assert log2(4.0) == 2
    assert log2(0.5) == -1

def test_invalid_numbers():
    with pytest.raises(ValueError):
        log2(-1)
    with pytest.raises(ValueError):
        log2(0)
        
def test_strings(capsys):
    log2("8")
    captured_stdout, captured_stderr = capsys.readouterr()
    assert captured_stdout.strip() == "Input must be a number."
    
    log2("hello")
    captured_stdout, captured_stderr = capsys.readouterr()
    assert captured_stdout.strip() == "Input must be a number."

def test_edge_cases():
    assert log2(1.0) == 0
    assert log2(2.0) == 1

def test_precision():
    assert log2(3) == pytest.approx(1.58496250072)
    assert log2(5) == pytest.approx(2.32192809489)