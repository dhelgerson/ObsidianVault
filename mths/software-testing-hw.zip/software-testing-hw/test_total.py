import pytest
from fixedFunctions import total

def test_base():
    assert total(3,6) == 12
    
def test_noLength():
    assert total(3,3) == 0

def test_backwards():
    with pytest.raises(ValueError):
        total(6,3)

def test_oneArgument():
    with pytest.raises(TypeError):
        total(6)

def test_wrongType():
    with pytest.raises(TypeError):
        total([3,6])