import pytest
from fixedFunctions import divide

# Generate inputs for testing
def gen_inputs(input1, input2): 
    inputs = [input1, input2]
    
    for item in inputs: 
        yield item

def test_divide_positive_numbers(monkeypatch, capsys):
    input = gen_inputs(10, 2)
    monkeypatch.setattr('builtins.input', lambda _: next(input))
    divide()
    captured_stdout, captured_stderr = capsys.readouterr()
    assert captured_stdout.strip() == "Your numbers divided is: 5.0"
    
    input = gen_inputs(20, 4)
    monkeypatch.setattr('builtins.input', lambda _: next(input))
    divide()
    captured_stdout, captured_stderr = capsys.readouterr()
    assert captured_stdout.strip() == "Your numbers divided is: 5.0"

def test_divide_negative_numbers(monkeypatch, capsys):
    input = gen_inputs(-10, 2)
    monkeypatch.setattr('builtins.input', lambda _: next(input))
    divide()
    captured_stdout, captured_stderr = capsys.readouterr()
    assert captured_stdout.strip() == "Your numbers divided is: -5.0"
    
    input = gen_inputs(20, -4)
    monkeypatch.setattr('builtins.input', lambda _: next(input))
    divide()
    captured_stdout, captured_stderr = capsys.readouterr()
    assert captured_stdout.strip() == "Your numbers divided is: -5.0"

def test_divide_by_zero(monkeypatch, capsys):
    input = gen_inputs(0, 1)
    monkeypatch.setattr('builtins.input', lambda _: next(input))
    divide()
    captured_stdout, captured_stderr = capsys.readouterr()
    assert captured_stdout.strip() == "Your numbers divided is: 0.0"
    
    input = gen_inputs(0, -1)
    monkeypatch.setattr('builtins.input', lambda _: next(input))
    divide()
    captured_stdout, captured_stderr = capsys.readouterr()
    assert captured_stdout.strip() == "Your numbers divided is: -0.0"

def test_divide_by_zero_denominator(monkeypatch, capsys):
        input = gen_inputs(10,0)
        
        monkeypatch.setattr('builtins.input', lambda _: next(input))
        divide()
        captured_stdout, captured_stderr = capsys.readouterr()
        assert captured_stdout.strip() == "You cannot divide by zero."
        
        input = gen_inputs(-10,0)
        monkeypatch.setattr('builtins.input', lambda _: next(input))
        divide()
        captured_stdout, captured_stderr = capsys.readouterr()
        assert captured_stdout.strip() == "You cannot divide by zero."

def test_number_strings(monkeypatch, capsys):
    input = gen_inputs("10", 2)
    monkeypatch.setattr('builtins.input', lambda _: next(input))
    divide()
    captured_stdout, captured_stderr = capsys.readouterr()
    assert captured_stdout.strip() == "Your numbers divided is: 5.0"
    

    input = gen_inputs(10, "2")
    monkeypatch.setattr('builtins.input', lambda _: next(input))
    divide()
    captured_stdout, captured_stderr = capsys.readouterr()
    assert captured_stdout.strip() == "Your numbers divided is: 5.0"
        
def test_word_strings(monkeypatch):
    with pytest.raises(ValueError):
        input = gen_inputs("ten", 2)
        monkeypatch.setattr('builtins.input', lambda _: next(input))
        divide()
    
    with pytest.raises(ValueError):
        input = gen_inputs(10, "two")
        monkeypatch.setattr('builtins.input', lambda _: next(input))
        divide()