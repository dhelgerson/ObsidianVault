import pytest
import os
from fixedFunctions import openFile, numbers, dist

# Test cases for openFile function
def test_openFile_existing_file():
    try:
        open("existing_file.txt","w")
        openFile("existing_file.txt")  # Assume "existing_file.txt" exists
        os.remove("existing_file.txt")
        
    except FileNotFoundError:
        pytest.fail("File should exist.")

def test_openFile_nonexistent_file():
    with pytest.raises(FileNotFoundError):
        openFile("nonexistent_file.txt")

def test_openFile_directory_instead_of_file():
    os.mkdir("directory/")
    with pytest.raises(IsADirectoryError):
        openFile("directory/")  # Assume "directory/" is a directory, not a file
    os.rmdir("directory/")

def test_openFile_wrong_file_type():
    with pytest.raises(ValueError):
        openFile(12345)  # Invalid file name type

def test_openFile_permissions():
    open("no_permission_file.txt","w")
    os.chmod("no_permission_file.txt",200)
    with pytest.raises(PermissionError):
        openFile("no_permission_file.txt")  # Assume "no_permission_file.txt" is restricted
    os.remove("no_permission_file.txt")

def test_openFile_valid_file():
    open("test.txt","w")
    assert openFile("test.txt") is None  # Check if it opens successfully without returning
    os.remove("test.txt")

# Test cases for numbers function
def test_numbers_divide_by_zero():
    with pytest.raises(ZeroDivisionError):
        numbers(5, 0)

def test_numbers_normal_division():
    assert numbers(10, 2) == 5

def test_numbers_float_division():
    assert numbers(5.5, 2.5) == 5.5 / 2.5

def test_numbers_large_numbers():
    assert numbers(1e10, 2) == 1e10 / 2

def test_numbers_negative_division():
    assert numbers(-10, 5) == -2

def test_numbers_invalid_type():
    with pytest.raises(TypeError):
        numbers("a", 2)

# Test cases for dist function
def test_dist_positive_coords():
    assert dist(0, 0, 3, 4) == 5.0

def test_dist_negative_coords():
    assert dist(-1, -1, -4, -5) == 5.0

def test_dist_mixed_coords():
    assert dist(1, 2, -1, -2) == 4.47213595499958

def test_dist_same_points():
    assert dist(3, 3, 3, 3) == 0.0

def test_dist_large_numbers():
    assert dist(1e6, 1e6, 2e6, 2e6) == 1414213.562373095

def test_dist_invalid_input_type():
    with pytest.raises(TypeError):
        dist("a", 2, 3, 4)
