Methods and Tools – Software Testing Assignment
Mrs. Kortni Neal
October 22, 2024

# I. Group Information
    Devin Chen – dc2368
    Hudson Hargrove – hth113
    Timothy (Drew) Helgerson – tah568
    Project Group 4

## Function Division

### Devin Chen:
- openFile
- numbers
- dist

### Hudson Hargrove:
- isPalindrome
- divide
- log2

### Drew Helgerson:
- ageResponse
- displayItem
- total

\pagebreak
# II. Test Cases

## openFile
- Number of tests: 6
- Items to test:
    - Existing file
        - Makes sure that the file opens successfully.
    - Non-existent file
        - FileNotFoundError when file does not exist.
    - Directory instead of file
        - IsADirectoryError is passed if a directory path is passed instead of a file.
    - Invalid file type (not a string)
        - ValueError raised if a non-string value is provided.
    - Restricted permissions
        - PermissionError if a file is attempted to be opened without permissions.
    - Valid file
        - Ensures that the function opens a valid file without returning any value.

- Corrections made:
    - The function openFile originally lacked some error handling for non-existent files, 	directories, invalid file types, and permissions issues. Added try-except blocks to catch 	the FileNotFoundError and PermissionError as well as added input type validation.
    - Failed tests:
        - Non-existent file and restricted permissions tests initially failed due to unhandled exceptions. Adding try-except blocks allowed for these to pass. Additionally, the invalid file type initially failed due to a non-string causing a Type Error. Validating the input 	type before opening it fixed this.
    - Tests passed before corrections:  1
    - Tests failed before corrections:  5
    - Tests passed after corrections:   6
    - Tests failed after corrections:   0

\pagebreak
## numbers
- Number of tests: 6
- Items to test:
    - Division by zero
        - Test that dividing by zero raises a ZeroDivisionError.
    - Normal Division
        - Test that standard division results in the correct answer.
    - Division with float values
        - Dividing two floats returns the expected float result.
    - Division with large numbers
        - Dividing with large numbers results in the expected result.
    - Division with negative numbers
        - Dividing negative by positive results in the currect negative result.
    - Invalid input type
        - Test that provides a non-numeric input raises a TypeError.
    - Inputs used for testing:
        - 5/0
        - 10/2
        - 5.5/2.5
        - 1e10/2
        - -10/5
        - “a”/2
- Corrections made:
    - The numbers function lacked a way to validate input, basically checking if we have an 	integer or float. Specifically, item 6 was fixed, making sure that a TypeError is raised for 	any non-numeric inputs.
    - Failed tests:
        - Initially the test_numbers_invalid_type failed, because there was no type validation.
    - Tests passed before corrections: 5
    - Tests failed before corrections: 1
    - Tests passed after corrections: 6
    - Tests failed after corrections: 0

\pagebreak
## dist
- Number of tests: 6
- Items to test:
    - Distance calculation with positive coordinates
        - Test that calculating the distance between two points in the first quadrant is done correctly.
    - Distance calculation with negative coordinates.
        - Making sure that distance between two points in the third quadrant is done properly.
    - Distance calculation with mixed coordinates.
        - Testing that the distance is correctly computed when points are in different quadrants from each other.
    - Distance calculation for the same points
        - Testing that the distance calculation for the same point results in 0.
    - Distance calculation with large numbers
        - Making sure that when taking the distance between two large coordinates, the right value is returned.
    - Invalid input type
        - TypeError when providing a non-numeric input.
- Inputs used for testing:
        - (0,0) and (3,4)
        - (-1,-1) and (-4,-5)
        - (1,2) and (-1,-2)
        - (3,3) and (3,3)
        - (1e6, 1e6) and (2e6, 2e6)
        - (“a”, 2) and (3,4)
- Corrections made:
    - The dist function was updated to validate the types of all input coordinates. Bsically 	ensuring that a TypeError will be raised if any input is not an integer or float, taking care 	of the issue with Item 6.
- Failed tests:
        - Initially test_dist_invalid_input_type was not catching due to missing type validation.
    - Tests passed before corrections: 5
    - Tests failed before corrections: 1
    - Tests passed after corrections: 6
    - Tests failed after corrections: 0

\pagebreak
## isPalindrome
- Number of tests: 6
- Items to test:
    - Regular Palindromes
        - Checks to make sure a regular palindrome with no capital letters numbers or whitespace will pass
    - Capital Palindromes
        - Checks to make sure a word starting with a capital but is otherwise a palindrome will pass
    - Numeric Palindromes
        - Checks to make sure that a sequence of numbers will raise a type error
    - Char Palindromes
        - Checks to make sure any single char will pass. Chars are trivially considered palindromes
    - Mixed String Palindromes
        - Checks to make sure a string containing numbers and letters will pass if it is a palindrome
    - Test Whitespace
        - Checks to make sure phrases whitespace is fully cut out and if it’s a palindrome it will pass
    - Inputs used for testing:
        - “hello” and “racecar”
        - “Racecar” and “Hello”
        - 123321 and 123456
        - “b” and “r”
        - “123rr321” and gh23d1d132hg
        - “Hi how are you uoy era woh iH” and “A man a plan a canal Panama” Corrections made:
    - Changes made:
        - The isPalindrome function was updated to strip whitespace from phrases, .lower() all strings before comparison, and raise a type error for non strings
    - Failed tests:
        - test_case_sensitivity, test_numeric, and test_whitespace all failed initially because there was no type checking stripping or lowering in the original function.
    - Tests passed before corrections: 3
    - Tests failed before corrections: 3
    - Tests passed after corrections: 6
    - Tests failed after corrections: 0

\pagebreak
## divide
- Number of tests: 6
- Items to test:
    - Regular Numbers
        - Checks to make sure regular positive numbers will work properly
    - Negative Numbers
        - Checks to make sure dividing negative numbers will work properly
    - 0 Numerator
        - Checks to make sure division with a 0 numerator returns 0
    - 0 Denominator
        - Checks to make sure division with a 0 denominator returns a ZeroDivisionError
    - Number Strings
        - Checks to make sure number strings are converted properly
    - Other Strings
        - Checks to make sure all other strings return a ValueError
- Inputs used for testing:
    - 10,2 and 20,4
    - -10,2 and 20,-4
    - 0,1 and 0,-1
    - 10,0 and -10,0
    - “10”,2 and 10,”2”
    - “ten”, 2 and 10,”two”
- Corrections made:
    - The divide function was updated with a try except block to raise a value error if the input cannot be converted to an int. I also added a printed message when trying to divide by zero
- Failed tests:
    - Test_divide_by_zero
- Tests passed before corrections: 5
- Tests failed before corrections: 1
- Tests passed after corrections: 6
- Tests failed after corrections: 0

\pagebreak
## log2
- Number of tests: 6
- Items to test:
    - Regular Numbers
        - Checks to make sure passing positive numbers will work properly
    - Floats
        - Checks to make sure passing floats will work properly
    - Invalid Numbers
        - Checks to make sure a ValueError is thrown on negative numbers and 0
    - Strings
        - Checsk to make sure strings throw a TypeError
    - Edge Cases
        - Checks to make sure edge cases like log(1) and log(2) are handled properly
    - Precision
        - Checks to make sure that the returned value has the correct precision
- Inputs used for testing:
    - 8 and 1 and 2
    - 4.0 and 0.5
    - -1 and 0
    - “string” and None
    - 1.0 and 2.0
    - 3 and 5
- Changes made:
    - I added a message when trying to get the log of a string
- Failed tests:
    - test_strings
- Tests passed before corrections: 5
- Tests failed before corrections: 1
- Tests passed after corrections: 6
- Tests failed after corrections: 0

\pagebreak
## ageResponse
- Number of tests: 5
- Items to test:
    - minor
        - does the function correctly identify a minor
    - grey area
        - does the function correctly identify a person of 19-20
    - legal
        - does function correctly identify a person 21 or older
    - string
        - does fuction correctly raise TypeError when passed a string
    - neg
        - does function correctly raise ValueError when passed a negative age
- Inputs used for testing:
    - 17
    - 20
    - 21
    - "tehee" - an invalid string
    - -1 - an invalid negative age
- Changes made:
    - added a check if the age is negative. before negative ages would just return the under 18 response
    - fixed logical error with age ranges. all ages over 18 would be identified as grey area
- Failed Tests:
    - neg
- Tests passed before corrections: 4
- Tests failed before corrections: 1
- Tests passed after corrections: 5
- Tests failed after corrections: 0

\pagebreak
## displayItem
- Number of tests: 5
- Items to test:
    - isInts:
        - check whether passing an int is handled. I decided that ints should be treated as a list of single digit numbers.
    - isString:
        - a base case to check if function returns the index of a string
    - isList:
        - another base case, since lists have indicies
    - isSet:
        - a check to make sure that an exception is raised since by definition, sets are unordered and don't have indicies
    - indexOutOfRange:
        - make sure exception is raised when index is out of range.
- Inputs used for testing:
    - 1234,2
    - "1234",2
    - [1,2,3,4],2
    - {1,2,3,4},2
    - [1,2,3,4],4
- Changes made:
    - Handling of strings
- Failed Tests:
    - isString
- Tests passed before corrections: 4
- Tests failed before corrections: 1
- Tests passed after corrections: 5
- Tests failed after corrections: 0

\pagebreak
## total:
- Number of tests: 5
- Items to test:
    - base
        - make sure the base case works
    - noLength
        - ensure that having the total of length 0 doesn't error out
    - backwards
        - function should error if start is greater than end
    - oneArgument
        - function should raise TypeError if only 1 of the 2 arguments is passed.
    - wrongType
        - function should raise TypeError if wrong type is given
- Inputs used for testing:
    - 3,6
    - 3,3
    - 6,3
    - 6
    - [3,6] - makes senes if someone things you can pass a list of [start,end]
- Changes made:
    - raise error if start > end
- Failed Tests
    - backwards
- Tests passed before corrections: 4
- Tests failed before corrections: 1
- Tests passed after corrections: 5
- Tests failed after corrections: 0


\pagebreak
# III. Reflections

1. Is there anything testing wise you feel was lacking (how the tests are performed)? Is it due to lack of tools, etc.?
    - dc2368: I wish there was a variety of tools to test errors. 
    - tah568: I wish it was easier to tell what kind of errors exist to throw
    - hth113: I wish I could more easily tell what was happening like a variable dump on failure
2. If you were to add more types of tests to certain functions, what could you expand upon?
    - dc2368: better performance testing for large data sets.
    - tah568: a more thorough test of the correct values would be a good idea.
    - hth113: I would add more edge case research and testing
3. After the assignment, do you feel that unit testing is important? Why or why not?
    - tah568: yes. I feel it's very important. I also really like setting up a bash while loop so that I can just hit enter whenever I make a change and see if I broke or fixed something.
    - hth113: Yes I think it's important because without it you wouldn't really know if a change you made caused an unexpected bug somewhere else in the functionailty
    - dc2368: Yes, it is super important because it helps with better code quality. 

![Attach your PyTest result window here](pytest_screenshot.png)
