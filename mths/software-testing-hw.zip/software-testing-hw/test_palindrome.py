import pytest 
from fixedFunctions import isPalindrome

def test_is_palindome():
    #Test for regular palindromes
    assert isPalindrome("hello") == False
    assert isPalindrome("racecar") == True
    
def test_case_sensitivity():
    #Assert non case sensitivity
    assert isPalindrome("Racecar") == True
    assert isPalindrome("Hello") == False
    
def test_numeric():
    with pytest.raises(TypeError):
        isPalindrome(12321)
    with pytest.raises(TypeError):
        isPalindrome(45654)

def test_char_string():
    assert isPalindrome("b") == True
    assert isPalindrome("R") == True

def test_mixed_string():
    assert isPalindrome("123rr321") == True
    assert isPalindrome("gh23d1d132hg") == False
    
def test_whitespace():
    assert isPalindrome("Hi how are you uoy era woh iH") == True
    assert isPalindrome("A man a plan a canal Panama") == True


