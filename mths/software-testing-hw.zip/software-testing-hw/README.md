# Methods-and-Tools-ST
Software Testing for Methods and Tools Assignment

## Testing:
all tests are named according to pytest's naming scheme. you can run them all w/ `pytest` or `pytest -v` to see the names of all tests.

## File explanations:
- main.py - the old functions file
- fixedFunctions.py - the updated functions file
- README.md - this file
- test_\*.py - all of our pytest declarations
- pytest.mkv - a screen recording of the terminal window running pytest on all files.
- pytest_screenshot.png - the screenshot of the completed pytest instance attached in the pdf

## Notes:
- pdf generated from docs.md using pandoc.
