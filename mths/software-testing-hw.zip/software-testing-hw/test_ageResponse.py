import pytest
from fixedFunctions import ageResponse

def test_ageResponse_minor(capsys):
    # test handling of strings instead of integers
    ageResponse(17)
    captured_stdout, captured_stderr = capsys.readouterr()
    assert captured_stdout.strip() == "You're a minor!"

def test_ageResponse_grey_area(capsys):
    # test handling of strings instead of integers
    ageResponse(20)
    captured_stdout, captured_stderr = capsys.readouterr()
    assert captured_stdout.strip() == "You're kind of in a weird legal gray area of ages."

def test_ageResponse_legal(capsys):
    # test handling of strings instead of integers
    ageResponse(21)
    captured_stdout, captured_stderr = capsys.readouterr()
    assert captured_stdout.strip() == "You're 21 or older!\nYou can now drink alcohol AND get married without parental consent in MS. Congrats."

def test_ageResponse_string():
    # checks to make sure errors are raised if strings are passed.
    with pytest.raises(TypeError):
        ageResponse("tehee")
        
def test_ageResponse_neg():
    # checks if an exception is raised when a negative number is passed
    with pytest.raises(ValueError):
        ageResponse(-1)
        
    