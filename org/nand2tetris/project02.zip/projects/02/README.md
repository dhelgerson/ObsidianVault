## Project 2 submission:
#####  Drew Helgerson

overall this project was easy. I had a little snag on the hdl syntax of the stat part of the alu, specifically getting the data from 'out' to 3 different parts. thanks to Devin Neal for clarifying that. 