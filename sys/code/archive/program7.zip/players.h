extern int player1_status, player2_status;
extern int player1_response, player2_response;

void player1();
void player2();
