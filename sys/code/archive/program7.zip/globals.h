#define NUM 62

extern pid_t ref_pid,player1_pid,player2_pid;
