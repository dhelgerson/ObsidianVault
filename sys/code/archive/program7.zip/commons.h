void handlersetup(void *handler);
int checkerr(int val, const char *msg);