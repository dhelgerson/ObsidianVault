void parentsighandler(int sig);
void player1sighandler(int sig);
void player2sighandler(int sig);
